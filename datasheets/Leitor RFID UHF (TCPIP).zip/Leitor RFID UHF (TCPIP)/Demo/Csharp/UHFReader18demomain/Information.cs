﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHFReader18demomain
{
    public class Information
    {
        public static string IP = "";
        public static string usename = "";
        public static string dsname = "";
        public static string mac = "";
        public static string portnum = "";
        public static string tup = "";
        public static string rm = "";
        public static string cm = "";
        public static string ct = "";
        public static string fc = "";
        public static string dt = "";
        public static string br = "";
        public static string pr = "";
        public static string bb = "";
        public static string rc = "";
        public static string ml = "";
        public static string md = "";
        public static string di = "";
        public static string dp = "";
        public static string gi = "";
        public static string nm = "";
    }
}
